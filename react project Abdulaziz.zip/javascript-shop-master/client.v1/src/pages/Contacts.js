import Container from 'react-bootstrap/Container'

const Contacts = () => {
    return (
        <Container>
            <h1>Контакты</h1>
        </Container>
    )
}

export default Contacts